//
//  Day5Tests.swift
//  Day5Tests
//
//  Created by U48738 on 12/31/25.
//


import XCTest
@testable import Day5

final class BalanceViewModelTests: XCTestCase {

    func testLoadBalanceSuccess() async {
        // Arrange
        let mockService = BalanceServiceMock()
        mockService.result = .success(1500.50)
        let viewModel = BalanceViewModel(service: mockService)

        // Act
        await viewModel.loadBalance(accountId: "12345")

        // Assert
        XCTAssertFalse(viewModel.isLoading, "isLoading debe ser false al terminar")
        XCTAssertEqual(viewModel.balance, 1500.50, "El balance debe coincidir con el mock")
        XCTAssertNil(viewModel.errorMessage, "No debe haber error en caso de éxito")
        XCTAssertEqual(viewModel.formattedBalance, "RD$ 1500.50")
    }

    func testLoadBalanceFailure() async {
        // Arrange
        let mockService = BalanceServiceMock()
        mockService.result = .failure(MockError.networkError)
        let viewModel = BalanceViewModel(service: mockService)

        // Act
        await viewModel.loadBalance(accountId: "12345")

        // Assert
        XCTAssertFalse(viewModel.isLoading, "isLoading debe ser false al terminar")
        XCTAssertEqual(viewModel.balance, 0.0, "El balance debe permanecer en 0 ante error")
        XCTAssertEqual(viewModel.errorMessage, "No se pudo cargar el saldo.")
    }
}

