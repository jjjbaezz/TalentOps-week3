//
//  BalanceServiceMock.swift
//  Day5Tests
//
//  Created by U48738 on 1/6/26.
//

import Foundation

protocol BalanceServiceProtocol {
    func fetchBalance(accountId: String) async throws -> Double
}

final class BalanceServiceMock: BalanceServiceProtocol {
    var result: Result<Double, Error> = .success(1000.0)
    
    func fetchBalance(accountId: String) async throws -> Double {
        switch result {
        case .success(let value):
            return value
        case .failure(let error):
            throw error
        }
    }
    
    enum MockError: Error {
        case networkError
    }
}
