//
//  BalanceCoordinator.swift
//  Day5
//
//  Created by U48738 on 12/31/25.
//

import SwiftUI

enum Route: Hashable {
    case balance(accountId: String)
}

@MainActor
final class BalanceCoordinator: ObservableObject{
   
    @Published var path = NavigationPath()
    
    func start(accountId: String) {
        path.append(Route.balance(accountId: accountId))
    }
    
    func navigateToBalance(accountId: String) {
        start(accountId: accountId)
    }
}
