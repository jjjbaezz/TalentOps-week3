//
//  Day5App.swift
//  Day5
//
//  Created by U48738 on 12/31/25.
//

import SwiftUI

@main
struct Day5App: App {
    var body: some Scene {
        
        let viewModel = BalanceViewModel()
        let accountId: String = "1234567890"
        
        WindowGroup {
            BalanceView(viewModel: viewModel, accountId: accountId)
        }
    }
}
