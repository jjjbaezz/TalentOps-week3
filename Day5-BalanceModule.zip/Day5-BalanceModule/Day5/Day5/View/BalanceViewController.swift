//
//  BalanceViewController.swift
//  Day5
//
//  Created by U48738 on 12/31/25.
//

import SwiftUI

struct BalanceView: View {
    @StateObject var viewModel: BalanceViewModel
    let accountId: String

    var body: some View {
        VStack(spacing: 16) {
            if viewModel.isLoading {
                ProgressView("Cargando saldo")
            } else {
                Text(viewModel.formattedBalance)
                    .font(.system(size: 28, weight: .bold, design: .rounded))
            }

            Button("Recargar") {
                Task { await viewModel.loadBalance(accountId: accountId) }
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .navigationTitle("Balance")
        .task {
            await viewModel.loadBalance(accountId: accountId)
        }
    }
}

