//
//  BalanceViewModel.swift
//  Day5
//
//  Created by U48738 on 12/31/25.
//

import SwiftUI

@MainActor
class BalanceViewModel: ObservableObject{
    @Published var balance: Double = 0.0
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    
    private let service: BalanceServiceProtocol
    
    init (service: BalanceServiceProtocol = BalanceService()) {
        self.service = service
    }
    
    func loadBalance(accountId: String) async {
        isLoading = true
        defer { isLoading = false }
        
        do{
            let value = try await service.getBalance(accountId: accountId)
            balance = value
        } catch {
            errorMessage = "No se pudo cargar el saldo"
        }
    }
    
    var formattedBalance: String{
        String(format: "%.2f", balance)
    }
}
