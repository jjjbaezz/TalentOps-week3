//
//  Day1_MVVM_CApp.swift
//  Day1-MVVM-C
//
//  Created by U48738 on 12/22/25.
//

import SwiftUI

@main
struct Day1_MVVM_CApp: App {
    var body: some Scene {
        
        let viewmodel = AccountViewModel()
        let coordinator = AccountCoordinator(viewModel: viewmodel)
        
        WindowGroup {
            AccountView(viewModel: viewmodel, coordinator: coordinator)
        }
    }
}
