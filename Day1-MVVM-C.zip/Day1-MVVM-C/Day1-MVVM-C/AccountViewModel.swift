//
//  AccountViewModel.swift
//  Day1-MVVM-C
//
//  Created by U48738 on 12/22/25.
//

import Foundation

class AccountViewModel: ObservableObject {
    @Published var accounts: [Account] = []
    
    @Published var selectedAccount: ((Account) -> Void)?
    
    
    func loadAccounts() {
        accounts = [
            .init(id: "1", name: "A", balance: 1000),
            .init(id: "2", name: "B", balance: 2000),
        ]
    }

    func selectAccount(_ account: Account) {
        selectedAccount?(account)
    }
}
