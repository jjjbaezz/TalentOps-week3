//
//  AppCoordinator.swift
//  Day1-MVVM-C
//
//  Created by U48738 on 12/22/25.
//

import SwiftUI

class AppCoordinator: ObservableObject {
    
    enum AppFlow {
        case loading
        case accounts
    }
    
    @Published var currentFlow: AppFlow = .loading
    
    var accountCoordinator: AccountCoordinator?

    func start() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.setupAccountFlow()
        }
    }
    
    private func setupAccountFlow() {
        let viewModel = AccountViewModel()
        self.accountCoordinator = AccountCoordinator(viewModel: viewModel)
        self.currentFlow = .accounts
    }
}
