//
//  AccountDetailView.swift
//  Day1-MVVM-C
//
//  Created by U48738 on 12/22/25.
//

import Foundation

import SwiftUI

struct AccountDetailView: View {
    
    let account: Account

    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "creditcard.fill")
                .resizable()
                .frame(width: 100, height: 70)
                .foregroundColor(.blue)
            
            Text("Detalle de la Cuenta")
                .font(.title2)
                .bold()
            
            Divider()
            
            HStack {
                Text("ID de Cuenta:")
                    .foregroundColor(.secondary)
                Spacer()
                Text(account.id)
                    .bold()
            }
            .padding(.horizontal)
            
            HStack {
                Text("Saldo Disponible:")
                    .foregroundColor(.secondary)
                Spacer()
                Text("$\(account.balance, specifier: "%.2f")")
                    .foregroundColor(.green)
                    .bold()
            }
            .padding(.horizontal)
            
            Spacer()
        }
        .padding()
        .navigationTitle("Detalles")
       
    }
}
