//
//  Account.swift
//  Day1-MVVM-C
//
//  Created by U48738 on 12/22/25.
//

import Foundation

struct Account: Hashable, Identifiable {
    let id: String
    let name: String
    let balance: Double
}
