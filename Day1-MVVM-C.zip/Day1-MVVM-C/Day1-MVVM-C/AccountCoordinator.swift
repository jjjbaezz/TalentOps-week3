//
//  AccountCoordinator.swift
//  Day1-MVVM-C
//
//  Created by U48738 on 12/22/25.
//


import SwiftUI

class AccountCoordinator: ObservableObject {
    @Published var path = NavigationPath()
    var viewModel: AccountViewModel
    
    init(viewModel: AccountViewModel) {
        self.viewModel = viewModel
        self.viewModel.selectedAccount = { [weak self] account in
            self?.navigateToDetail(account: account)
        }
    }
    
    func navigateToDetail(account: Account) {
        path.append(account)
    }
}
