//
//  AccountViewController.swift
//  Day1-MVVM-C
//
//  Created by U48738 on 12/22/25.
//



import SwiftUI

struct AccountView: View {

    @ObservedObject var viewModel: AccountViewModel
    @ObservedObject var coordinator: AccountCoordinator

    var body: some View {
        NavigationStack(path: $coordinator.path) {
            List(viewModel.accounts) { account in
                Button(action: {
                    viewModel.selectAccount(account)
                }) {
                    HStack {
                        Text("Cuenta: \(account.id)")
                        Spacer()
                        Text("$\(account.balance, specifier: "%.2f")")
                    }
                }
            }
            .navigationTitle("Mis Cuentas")
            .navigationDestination(for: Account.self) { account in
                AccountDetailView(account: account)
            }
        }
    }
}
